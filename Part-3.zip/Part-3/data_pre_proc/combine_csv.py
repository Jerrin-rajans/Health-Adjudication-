import pandas as pd

# Load the dataframes
df_health = pd.read_csv('/Users/jerrin.rajan/Desktop/BIA/Part-3/data/health_data.csv')
df_progress = pd.read_csv('/Users/jerrin.rajan/Desktop/BIA/Part-3/data/fast_patient_analysis_progress_v2.csv')

# Identify common columns automatically
common_columns = list(set(df_health.columns).intersection(set(df_progress.columns)))
print(f"Common columns identified: {common_columns}")

# Merge the dataframes on the identified common columns
# An inner merge ensures we only keep rows present in both datasets with matching keys
df_combined = pd.merge(df_health, df_progress, on=common_columns, how='inner')

# Display the result info
print(f"Combined Dataframe Shape: {df_combined.shape}")


# Save the combined dataframe to a CSV file for further use
df_combined.to_csv('combined_health_data.csv', index=False)