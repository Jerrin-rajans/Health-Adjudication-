import pandas as pd
import numpy as np
import joblib
import json

# ==========================================
# 1. SETUP & LOAD ARTIFACTS
# ==========================================
print("Loading artifacts and data...")

# Load the Model & Encoders
try:
    rf_model = joblib.load('/Users/jerrin.rajan/Desktop/BIA/Part-3/Model_Files/random_forest_model.pkl')
    encoders = joblib.load('/Users/jerrin.rajan/Desktop/BIA/Part-3/Model_Files/label_encoders.pkl')
    print("✅ Model and Encoders loaded successfully.")
except FileNotFoundError as e:
    print(f" Error: {e}. Please ensure path is correct.")
    exit()

# Load the Data
# Use 'combined_health_data.csv' which has the original columns (ClaimAmount, Date, etc.)
df = pd.read_csv('/Users/jerrin.rajan/Desktop/BIA/Part-3/data_pre_proc/combined_health_data.csv') 
print(f"Loaded {len(df)} claims.")

# ==========================================
# 2. RE-CREATE MISSING FEATURES (MATCHING PART 1)
# ==========================================
print("Reconstructing model features...")

# A. Date Features (The model expects these!)
df['ClaimDate'] = pd.to_datetime(df['ClaimDate'], format='mixed', errors='coerce')
df['ClaimYear'] = df['ClaimDate'].dt.year
df['ClaimMonth'] = df['ClaimDate'].dt.month
df['ClaimDay'] = df['ClaimDate'].dt.day
df['ClaimWeekday'] = df['ClaimDate'].dt.weekday

# B. Count Features
df['Num_Medications'] = df['Medications'].apply(lambda x: len(str(x).split(',')) if pd.notna(x) else 0)
df['Num_Tests'] = df['Tests'].apply(lambda x: len(str(x).split(',')) if pd.notna(x) else 0)

# C. CPT Grouping
def get_cpt_group(code):
    try:
        code = int(code)
        if code < 20000: return 0 
        elif code < 50000: return 1 
        elif code < 70000: return 2 
        else: return 3
    except:
        return 0 
df['CPT_Group'] = df['ProcedureCode'].apply(get_cpt_group)

# D. Severity Flag
avg_claim = df['ClaimAmount'].mean()
df['Claim_Severity_Flag'] = (df['ClaimAmount'] > avg_claim).astype(int)

# E. Rename Relevance Score (Model likely expects exact casing)
if 'ICD_CPT_relevance_score' in df.columns:
    df.rename(columns={'ICD_CPT_relevance_score': 'ICD_CPT_Relevance_Score'}, inplace=True)
elif 'ICD_CPT_Relevance_Score' not in df.columns:
    df['ICD_CPT_Relevance_Score'] = 0.0 # Fallback

# ==========================================
# 3. ENCODE CATEGORICALS (IN-PLACE)
# ==========================================
# The model expects columns named 'DiagnosisCode', 'ProcedureCode', etc. 
# NOT 'DiagnosisCode_Encoded'. So we transform in-place.

cat_cols = [
    'DiagnosisCode', 'ProcedureCode', 'PatientGender', 'ProviderSpecialty',
    'PatientMaritalStatus', 'PatientEmploymentStatus', 'ProviderLocation',
    'ClaimType', 'ClaimSubmissionMethod', 'Visit_Reason'
]

def safe_transform(encoder, values):
    """Map unseen labels to the first known class to prevent crashing."""
    classes = set(encoder.classes_)
    safe_vals = [str(v) if str(v) in classes else encoder.classes_[0] for v in values]
    return encoder.transform(safe_vals)

for col in cat_cols:
    if col in df.columns and col in encoders:
        df[col] = safe_transform(encoders[col], df[col])

# ==========================================
# 4. ALIGN COLUMNS & PREDICT
# ==========================================
print("Aligning columns with model...")

# Automatically get the features the model was trained on
try:
    model_features = rf_model.feature_names_in_
except AttributeError:
    # Fallback if feature names aren't saved in the model object
    model_features = [
        'ClaimAmount', 'PatientAge', 'PatientGender', 'PatientIncome',
        'DiagnosisCode', 'ProcedureCode', 'ProviderSpecialty', 'ProviderLocation',
        'ClaimType', 'ClaimSubmissionMethod', 'Visit_Reason', 'PatientMaritalStatus',
        'PatientEmploymentStatus', 'ClaimYear', 'ClaimMonth', 'ClaimDay',
        'ClaimWeekday', 'Num_Medications', 'Num_Tests', 'ICD_CPT_Relevance_Score',
        'CPT_Group', 'Claim_Severity_Flag'
    ]

# Ensure all columns exist
for feat in model_features:
    if feat not in df.columns:
        print(f"Warning: Missing feature '{feat}', filling with 0")
        df[feat] = 0

# Select only the required columns in the correct order
X_final = df[model_features].fillna(0)

print("Generating Statistical Predictions...")
rf_probs = rf_model.predict_proba(X_final)
df['RF_Reject_Prob'] = rf_probs[:, 1]
df['RF_Decision'] = np.where(df['RF_Reject_Prob'] > 0.5, 'REJECT', 'APPROVE')

# ==========================================
# 5. HYBRID DECISION ENGINE
# ==========================================
print("Running Hybrid Logic...")

def make_final_decision(row):
    rf_dec = row['RF_Decision']
    rf_score = row['RF_Reject_Prob']
    billed_code = str(row['ProcedureCode']) # This is now encoded int!
    
    # We need to use the original procedure code string for matching LLM JSON
    # (Assuming we can't easily reverse extract here without decoding)
    # Strategy: Just trust the extracted text matching or use a heuristic.
    
    llm_dec = 'UNKNOWN'
    llm_reason = 'No extracted text data'

    try:
        if pd.notna(row.get('Line_Item_Decisions')):
            llm_data = json.loads(row['Line_Item_Decisions'])
            if isinstance(llm_data, list) and len(llm_data) > 0:
                # Simple: Take the first decision since matching encoded CPT is hard here
                llm_dec = llm_data[0].get('decision', 'UNKNOWN')
                llm_reason = llm_data[0].get('reason_short', 'Evaluated by LLM')
    except:
        pass

    # Rules
    if row.get('Policy_TOB_coverage_flag', 1) == 0:
        return pd.Series(["REJECT", 1.0, f"Policy Veto: {llm_reason}"])

    if rf_dec == llm_dec:
        return pd.Series([rf_dec, max(rf_score, 1-rf_score), f"Consensus: AI Models agree on {rf_dec}"])

    if rf_dec == 'REJECT' and llm_dec == 'APPROVE':
        if row['ICD_CPT_Relevance_Score'] > 0.7:
             return pd.Series(["APPROVE", 0.85, f"Medical Override: High relevance ({row['ICD_CPT_Relevance_Score']:.2f})"])
        else:
             return pd.Series(["REJECT", rf_score, "Statistical Reject: Low relevance"])

    if rf_dec == 'APPROVE' and llm_dec == 'REJECT':
        return pd.Series(["REJECT", 0.9, f"Semantic Reject: {llm_reason}"])

    return pd.Series([rf_dec, rf_score, "Statistical Decision (LLM Unknown)"])

df[['Final_Decision', 'Final_Confidence', 'Final_Reason']] = df.apply(make_final_decision, axis=1)

# ==========================================
# 6. SAVE OUTPUT
# ==========================================
final_json_output = []
# Recover ProcedureCode string for JSON output
decoded_proc = encoders['ProcedureCode'].inverse_transform(df['ProcedureCode'])

for idx, row in df.iterrows():
    record = {
        "cpt_code": str(decoded_proc[idx]),
        "decision": row['Final_Decision'],
        "confidence": round(float(row['Final_Confidence']), 2),
        "reason_short": row['Final_Reason'],
        "reason_detailed": f"Hybrid Logic -> RF Prob: {row['RF_Reject_Prob']:.2f} | Reason: {row['Final_Reason']}"
    }
    final_json_output.append(record)

with open('final_adjudication_results.json', 'w') as f:
    json.dump(final_json_output, f, indent=4)

df.to_csv('final_hybrid_results.csv', index=False)

