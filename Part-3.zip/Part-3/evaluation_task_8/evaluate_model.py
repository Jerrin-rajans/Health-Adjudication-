import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

# 1. Load Data
df = pd.read_csv('/Users/jerrin.rajan/Desktop/BIA/Part-3/decission_engine_task_7/final_hybrid_results.csv')

# 2. Define Column Names 
GROUND_TRUTH_COL = 'ClaimStatus'
PREDICTION_COL = 'Final_Decision'

# 3. Robust Normalization Function 
def normalize_label(val):
    val = str(val).strip().upper()
    if 'APPROV' in val: return 'APPROVE'
    # Checks for 'DENI' (Denied) OR 'REJECT'
    if 'REJECT' in val or 'DENY' in val or 'DENI' in val: return 'REJECT'
    return 'OTHER'

df['y_true'] = df[GROUND_TRUTH_COL].apply(normalize_label)
df['y_pred'] = df[PREDICTION_COL].apply(normalize_label)

# 4. Filter for Valid Binary Rows
valid_rows = df[
    (df['y_true'].isin(['APPROVE', 'REJECT'])) & 
    (df['y_pred'].isin(['APPROVE', 'REJECT']))
]

print(f"Evaluated on {len(valid_rows)} claims (Pending/Other excluded).")

# 5. Generate Report
y_true = valid_rows['y_true']
y_pred = valid_rows['y_pred']

print("\n" + "="*40)
print(f"Accuracy: {accuracy_score(y_true, y_pred):.2%}")
print("="*40)
print(classification_report(y_true, y_pred, target_names=['APPROVE', 'REJECT']))

# 6. Plot Matrix
cm = confusion_matrix(y_true, y_pred, labels=['APPROVE', 'REJECT'])
plt.figure(figsize=(6, 5))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
            xticklabels=['Pred APPROVE', 'Pred REJECT'],
            yticklabels=['Actual APPROVE', 'Actual REJECT'])
plt.title('Confusion Matrix')
plt.savefig('/Users/jerrin.rajan/Desktop/BIA/Part-3/Outputs/confusion_matrix_corrected.png')
