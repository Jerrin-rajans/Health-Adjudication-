import csv
import io
from collections import defaultdict
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.enums import TA_CENTER, TA_LEFT

# --- 1. SIMULATED CSV DATA LOAD ---
# Added "General Practice" to the bottom of this list
csv_raw_data = """Specialty,Diagnosis_Reason,Medication,Diagnostic_Test,Max_Claim_Limit,Specific_Exclusion,CoPay_Percent
Cardiology,Chest Pain|Arrhythmia|Heart Failure|Hypertension,Lisinopril|Atorvastatin|Warfarin|Amlodipine,ECG|Echo|Angiogram|Stress Test,50000,Cosmetic Surgery|Experimental Valve,10%
Orthopedics,Fracture|Arthritis|Spondylitis|Ligament Tear,Ibuprofen|Calcium|Tramadol|Methotrexate,X-Ray|MRI|Bone Density|CT Scan,35000,Sports Injuries (Pro)|Massage Therapy,20%
Neurology,Migraine|Epilepsy|Stroke|Neuropathy,Topiramate|Aspirin|Levodopa|Gabapentin,EEG|CT Brain|MRI Brain|Spinal Tap,60000,Biofeedback|Experimental Neurostim,15%
Oncology,Breast Cancer|Leukemia|Lymphoma|Tumor,Tamoxifen|Cisplatin|Rituximab|Imatinib,Biopsy|PET Scan|Tumor Markers|CT Scan,150000,Alternative Medicine|Unproven Stem Cell,5%
Gastroenterology,Gastritis|IBS|Liver Cirrhosis|Ulcer,Omeprazole|Metronidazole|Lactulose|Pantoprazole,Endoscopy|Colonoscopy|Liver Function|Ultrasound,40000,Dietary Supplements|Detox Programs,15%
Pediatrics,Fever|Asthma|Infection|Bronchitis,Paracetamol|Amoxicillin|Inhalers|Ibuprofen,Blood Count|Urine Culture|X-Ray|Allergy Test,25000,Growth Hormones (Cosmetic)|Developmental Therapy,0%
General Practice,Abdominal Pain|Routine Checkup|Hypertension Follow-up|Fatigue,Ibuprofen|Lisinopril|Sertraline|Omeprazole|Metformin,Lipid Panel|TSH|CBC,Not Available,Not Available,N/A"""

def parse_csv_data(raw_data):
    """Parses raw CSV string into a structured dictionary keyed by Specialty."""
    policy_db = {}
    reader = csv.DictReader(io.StringIO(raw_data))
    
    for row in reader:
        spec = row['Specialty']
        policy_db[spec] = {
            'reasons': row['Diagnosis_Reason'].split('|'),
            'medications': row['Medication'].split('|'),
            'tests': row['Diagnostic_Test'].split('|'),
            'max_amount': row['Max_Claim_Limit'],
            'exclusions': row['Specific_Exclusion'].split('|'),
            'copay': row['CoPay_Percent']
        }
    return policy_db

# --- 2. PDF GENERATION LOGIC ---
def generate_master_policy_pdf(filename, policy_data):
    doc = SimpleDocTemplate(filename, pagesize=A4, rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40)
    story = []
    styles = getSampleStyleSheet()

    # Custom Styles
    title_style = ParagraphStyle('MainTitle', parent=styles['Heading1'], alignment=TA_CENTER, fontSize=26, textColor=colors.darkblue, spaceAfter=30)
    spec_header_style = ParagraphStyle('SpecHeader', parent=styles['Heading2'], fontSize=18, textColor=colors.white, backColor=colors.darkblue, borderPadding=8, spaceAfter=15)
    sub_header_style = ParagraphStyle('SubHeader', parent=styles['Heading3'], fontSize=12, textColor=colors.black, spaceAfter=5)
    normal_style = ParagraphStyle('NormalCustom', parent=styles['Normal'], fontSize=10, leading=14)

    # -- COVER PAGE --
    story.append(Spacer(1, 2*inch))
    story.append(Paragraph("MASTER MEDICAL ADJUDICATION POLICY", title_style))
    story.append(Paragraph("<b>Unified Coverage Schedule (All Specialties)</b>", ParagraphStyle('Subtitle', parent=styles['Normal'], alignment=TA_CENTER, fontSize=14)))
    story.append(Spacer(1, 0.5*inch))
    story.append(Paragraph("<b>Effective Year:</b> 2025-2026", ParagraphStyle('Date', parent=styles['Normal'], alignment=TA_CENTER, fontSize=12)))
    story.append(PageBreak())

    # -- LOOP THROUGH SPECIALTIES --
    for specialty, details in policy_data.items():
        # 1. Header
        story.append(Paragraph(f"SPECIALTY: {specialty.upper()}", spec_header_style))
        
        # 2. Financial Limits Table
        story.append(Paragraph("<b>1. Financial Parameters & Exclusions</b>", sub_header_style))
        
        # LOGIC UPDATE: Check if max_amount is a number or text (e.g., "Not Available")
        raw_limit = details['max_amount']
        if raw_limit.replace(',', '').isdigit(): 
            display_limit = f"${int(raw_limit):,}"
        else:
            display_limit = raw_limit  # Print "Not Available" as is

        limit_data = [
            ["Max Claim Limit", display_limit],
            ["Mandatory Co-Pay", details['copay']],
            ["Specific Exclusions", ", ".join(details['exclusions'])]
        ]
        
        t_limits = Table(limit_data, colWidths=[2*inch, 4.5*inch])
        t_limits.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.whitesmoke),
            ('GRID', (0, 0), (-1, -1), 1, colors.lightgrey),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('PADDING', (0, 0), (-1, -1), 8),
            ('VALIGN', (0,0), (-1,-1), 'TOP')
        ]))
        story.append(t_limits)
        story.append(Spacer(1, 0.2*inch))

        # 3. Clinical Rules Table (The "Logic")
        story.append(Paragraph("<b>2. Clinical Coverage Rules</b>", sub_header_style))
        
        rules_data = [
            [Paragraph("<b>Rule Type</b>", normal_style), Paragraph("<b>Authorized List</b>", normal_style)],
            ["Valid Diagnoses", Paragraph(", ".join(details['reasons']), normal_style)],
            ["Formulary Drugs", Paragraph(", ".join(details['medications']), normal_style)],
            ["Required Diagnostics", Paragraph(", ".join(details['tests']), normal_style)]
        ]

        t_rules = Table(rules_data, colWidths=[1.5*inch, 5*inch])
        t_rules.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.navy),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('PADDING', (0, 0), (-1, -1), 10),
        ]))
        story.append(t_rules)
        
        # 4. Footer for section
        story.append(Spacer(1, 0.5*inch))
        story.append(Paragraph(f"<i>* Claims under {specialty} exceeding limits require Medical Board Approval.</i>", 
                               ParagraphStyle('Note', parent=styles['Normal'], fontSize=8, textColor=colors.grey)))
        
        # Force new page for next specialty
        story.append(PageBreak())

    doc.build(story)
    print(f"Success! Master Policy PDF generated as: {filename}")

# --- EXECUTION ---
if __name__ == "__main__":
    # 1. Load Data
    data = parse_csv_data(csv_raw_data)
    
    # 2. Generate PDF
    generate_master_policy_pdf("Master_Medical_Policy_2025_Updated.pdf", data)