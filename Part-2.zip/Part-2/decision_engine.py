import pandas as pd
import json
import numpy as np
import os
from openai import OpenAI
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm

# 1. SETUP
# ==========================================
# WARNING: Do not commit your API key to public repositories.
# Best practice is to use environment variables.
api_key = os.environ.get("OPENAI_API_KEY") 
if not api_key:
    # If you must hardcode it for local testing, do it here, but be careful.
    api_key = "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"

client = OpenAI(api_key=api_key) 

# Load your data
df = pd.read_csv('merged_patient_data_all.csv')

# Configuration
EMBEDDING_BATCH_SIZE = 1000
MAX_WORKERS = 20  
CACHE = {}

# 2. DATA EXTRACTION (Updated to include Visit Reason)
# ==========================================
print("Extracting clinical context from JSON...")

def fast_extract(json_str):
    try:
        data = json.loads(json_str)
        rx = data.get('Extracted Prescription Data', {})
        policy = data.get('Insurance Policy Impact', [{}])[0]
        
        # safely join lists, handling None/Nulls
        diagnosis_str = ", ".join(rx.get('Diagnosis', []) or [])
        meds_str = ", ".join(rx.get('Medications', []) or [])
        visit_reason_str = ", ".join(rx.get('Visit Reason', []) or [])
        policy_exclusions = ", ".join(policy.get('Policy Impact', {}).get('exclusions', []) or [])
        
        return pd.Series([
            diagnosis_str,
            meds_str,
            rx.get('Tests', []) or [],  # Keep as list for history context
            policy_exclusions,
            visit_reason_str
        ])
    except:
        return pd.Series(["", "", [], "", ""])

# Apply extraction to creating 5 new columns
df[['diagnosis_text', 'meds_text', 'history_test_list', 'exclusions', 'visit_reason_text']] = df['unstructured'].apply(fast_extract)

# 3. BATCH EMBEDDINGS (Unchanged)
# ==========================================
print("\nGenerating Embeddings...")

def get_embeddings_batched(text_list, model="text-embedding-3-small", desc="Embeddings"):
    valid_indices = [i for i, t in enumerate(text_list) if isinstance(t, str) and t.strip()]
    valid_texts = [text_list[i] for i in valid_indices]
    
    embeddings = np.zeros((len(text_list), 1536))
    
    # Process in chunks to avoid rate limits
    for i in tqdm(range(0, len(valid_texts), EMBEDDING_BATCH_SIZE), desc=desc):
        chunk = valid_texts[i:i + EMBEDDING_BATCH_SIZE]
        try:
            res = client.embeddings.create(input=chunk, model=model)
            for j, item in enumerate(res.data):
                original_idx = valid_indices[i + j]
                embeddings[original_idx] = item.embedding
        except Exception as e:
            print(f"Batch error: {e}")
            
    return list(embeddings)

# Generate embeddings for Diagnosis (useful for clustering later, though not used in the rule loop below)
df['Diagnosis_embedding'] = get_embeddings_batched(df['diagnosis_text'].fillna("").tolist(), desc="Diagnosis Embeddings")

# 4. PARALLEL LLM DECISIONS (FIXED LOGIC)
# ==========================================
print(f"\nProcessing LLM decisions with {MAX_WORKERS} threads...")

def process_patient_row(row_data):
    # Unpack the row data, including the new 'visit_reason'
    (pid, diag, meds, exclusions, history_test_list, claimed_tests_str, visit_reason) = row_data
    
    # 1. IDENTIFY TARGETS
    if pd.isna(claimed_tests_str):
        return 0, "[]"
        
    targets = [t.strip() for t in str(claimed_tests_str).split(',') if t.strip()]
    
    if not targets:
        return 0, "[]"

    # 2. DECISION LOOP
    decisions = []
    coverage_flag = 1 
    
    # Pre-process exclusions list for quick keyword matching
    excl_list = [x.strip().lower() for x in str(exclusions).split(',') if x.strip()]

    for target in targets:
        # A. Quick Coverage Check (Rule Based)
        # If the test name appears in the exclusions list, flag it immediately.
        combined_req = (str(target) + " " + str(meds)).lower()
        for x in excl_list:
            if x in combined_req:
                coverage_flag = 0 
                break
        
        # B. LLM Decision
        # We include 'visit_reason' in the cache key so different reasons get different answers
        cache_key = f"{diag}||{target}||{visit_reason}"
        if cache_key in CACHE:
            decisions.append(CACHE[cache_key])
            continue

        # IMPROVED PROMPT
        prompt = f"""
        Context: 
        - Diagnosis: {diag}
        - VISIT REASON: "{visit_reason}"
        
        CLAIM ITEM TO REVIEW: "{target}"
        
        Patient History (for context): {history_test_list}
        Policy Exclusions: {exclusions}
        
        Task: Decide coverage for "{target}".
        
        RULES:
        1. APPROVE only if the test is medically necessary for the Diagnosis OR the Visit Reason.
        2. REJECT if the test is unrelated (e.g., "Cardiac MRI" for "Broken Toe").
        3. REJECT if listed in Policy Exclusions.
        
        Return JSON: {{"cpt_code": "{target}", "decision": "APPROVE"|"REJECT", "confidence": 0.0-1.0, "reason_short": "...", "reason_detailed": "..."}}.
        """
        try:
            res = client.chat.completions.create(
                model="gpt-3.5-turbo-0125",
                messages=[{"role": "user", "content": prompt}],
                temperature=0,
                response_format={"type": "json_object"}
            )
            decision_json = json.loads(res.choices[0].message.content)
            CACHE[cache_key] = decision_json
            decisions.append(decision_json)
        except Exception as e:
            decisions.append({"cpt_code": target, "decision": "ERROR", "reason_short": "API Fail"})

    return coverage_flag, json.dumps(decisions)

# Prepare rows for threading
rows_to_process = []
for idx, row in df.iterrows():
    rows_to_process.append((
        row['PatientID'], 
        row['diagnosis_text'], 
        row['meds_text'], 
        row['exclusions'], 
        row['history_test_list'], 
        row['Tests'],
        row['visit_reason_text'] # <--- PASSING THE NEW COLUMN
    ))

# Execute ThreadPool
results_list = [None] * len(rows_to_process)

with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
    # Map future to index to ensure order is preserved
    future_to_idx = {executor.submit(process_patient_row, r): i for i, r in enumerate(rows_to_process)}
    
    for future in tqdm(as_completed(future_to_idx), total=len(rows_to_process), desc="Decisions"):
        idx = future_to_idx[future]
        try:
            cov_flag, line_items = future.result()
            results_list[idx] = (cov_flag, line_items)
        except Exception as e:
            results_list[idx] = (0, "[]")

# 5. SAVE
# ==========================================
df['Policy_TOB_coverage_flag'] = [r[0] for r in results_list]
df['Line_Item_Decisions'] = [r[1] for r in results_list]

# Cleanup temporary columns
df.drop(columns=['diagnosis_text', 'meds_text', 'history_test_list', 'exclusions', 'visit_reason_text'], inplace=True)

df.to_csv('fast_patient_analysis_progress_v2.csv', index=False)
print("\nDone! Results saved to fast_patient_analysis_progress_v2.csv")