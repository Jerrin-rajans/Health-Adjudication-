import pandas as pd
import random

# 1. Load your CSV file
# Replace this filename with the name of your file
input_file = 'enhanced_health_insurance_claims_with_reasons.csv'
df = pd.read_csv(input_file)

# 2. Define the logical mappings for each specialty
specialty_data = {
    'Cardiology': {
        'reasons': ['Chest Pain', 'Hypertension', 'Palpitations', 'Shortness of Breath', 'Arrhythmia', 'Heart Failure Checkup', 'Angina'],
        'medications': ['Lisinopril', 'Atorvastatin', 'Metoprolol', 'Amlodipine', 'Warfarin', 'Furosemide', 'Clopidogrel', 'Nitroglycerin'],
        'tests': ['ECG', 'Echocardiogram', 'Stress Test', 'Lipid Panel', 'Troponin Test', 'Holter Monitor', 'Cardiac CT']
    },
    'Pediatrics': {
        'reasons': ['Fever', 'Annual Checkup', 'Vaccination', 'Ear Infection', 'Sore Throat', 'Cough', 'Rash', 'Growth Check', 'Stomach Pain'],
        'medications': ['Amoxicillin', 'Ibuprofen', 'Acetaminophen', 'Albuterol Inhaler', 'Azithromycin', 'Prednisolone', 'Ceftriaxone'],
        'tests': ['CBC', 'Strep Test', 'Influenza Test', 'Lead Screening', 'Hearing Test', 'Vision Screen', 'RSV Test']
    },
    'Neurology': {
        'reasons': ['Migraine', 'Seizure', 'Numbness', 'Tingling', 'Dizziness', 'Memory Loss', 'Tremors', 'Chronic Headaches', 'Neuropathy'],
        'medications': ['Gabapentin', 'Topiramate', 'Levetiracetam', 'Sumatriptan', 'Donepezil', 'Lamotrigine', 'Carbamazepine'],
        'tests': ['MRI Brain', 'EEG', 'CT Head', 'EMG', 'Nerve Conduction Study', 'Lumbar Puncture', 'Cognitive Assessment']
    },
    'General Practice': {
        'reasons': ['Flu Symptoms', 'Routine Checkup', 'Diabetes Management', 'Hypertension Follow-up', 'Abdominal Pain', 'Fatigue', 'Back Pain', 'Allergy', 'Infection'],
        'medications': ['Metformin', 'Lisinopril', 'Omeprazole', 'Simvastatin', 'Levothyroxine', 'Sertraline', 'Amoxicillin', 'Ibuprofen'],
        'tests': ['CBC', 'CMP', 'Lipid Panel', 'HbA1c', 'Urinalysis', 'TSH', 'Vitamin D Level']
    },
    'Orthopedics': {
        'reasons': ['Knee Pain', 'Back Pain', 'Fracture Follow-up', 'Joint Stiffness', 'Shoulder Pain', 'Arthritis', 'Sports Injury', 'Hip Pain'],
        'medications': ['Naproxen', 'Ibuprofen', 'Meloxicam', 'Tramadol', 'Cyclobenzaprine', 'Celecoxib', 'Hydrocodone'],
        'tests': ['X-Ray', 'MRI', 'Bone Density Scan', 'CT Scan', 'Arthroscopy']
    }
}

# 3. Define the function to generate data for each row
def generate_clinical_data(row):
    specialty = row['ProviderSpecialty']
    
    # Fallback for specialties not in our list
    if specialty not in specialty_data:
        return pd.Series(['General Checkup', 'Multivitamin', 'Blood Pressure Check'])
    
    data = specialty_data[specialty]
    
    # -- Logic for Reason --
    visit_reason = random.choice(data['reasons'])
    
    # -- Logic for Medications (Pick 1 or 2 randomly) --
    num_meds = random.choice([1, 1, 2])
    meds = random.sample(data['medications'], k=min(num_meds, len(data['medications'])))
    meds_str = ', '.join(meds)
    
    # -- Logic for Tests (Pick 1 or 2 randomly) --
    num_tests = random.choice([1, 1, 2])
    tests = random.sample(data['tests'], k=min(num_tests, len(data['tests'])))
    tests_str = ', '.join(tests)
    
    return pd.Series([visit_reason, meds_str, tests_str])

# 4. Apply the function to create the new columns
print("Generating new columns...")
new_cols = df.apply(generate_clinical_data, axis=1)
new_cols.columns = ['Visit_Reason', 'Medications', 'Tests']

# 5. Join the new columns with the original dataframe
df_enhanced = pd.concat([df, new_cols], axis=1)

# 6. Save the new file
output_file = 'enhanced_claims_with_clinical_data.csv'
df_enhanced.to_csv(output_file, index=False)

print(f"Success! New file saved as: {output_file}")
print(df_enhanced[['ProviderSpecialty', 'Visit_Reason', 'Medications']].head())