import pandas as pd
from reportlab.lib.pagesizes import letter, landscape
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import inch
from datetime import datetime
import os
from typing import List, Optional
import argparse


class PatientPDFGenerator:
    """Generate professional PDF reports for patient healthcare claims"""
    
    def __init__(self, csv_file: str, output_dir: str = 'patient_pdfs'):
        """
        Initialize the PDF generator
        
        Args:
            csv_file: Path to the cleaned CSV data file
            output_dir: Directory to store generated PDFs
        """
        self.csv_file = csv_file
        self.output_dir = output_dir
        self.df = None
        self.load_data()
        self._setup_styles()
        os.makedirs(output_dir, exist_ok=True)
    
    def load_data(self):
        """Load CSV data with error handling"""
        try:
            self.df = pd.read_csv(self.csv_file, encoding='utf-8')
            print(f"✓ Data loaded successfully: {len(self.df)} records")
        except Exception as e:
            print(f"✗ Error loading CSV: {e}")
            raise
    
    def _setup_styles(self):
        """Setup ReportLab styles for PDF generation"""
        styles = getSampleStyleSheet()
        
        self.title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=16,
            textColor=colors.HexColor('#1f4788'),
            spaceAfter=12,
            alignment=1
        )
        
        self.heading_style = ParagraphStyle(
            'CustomHeading',
            parent=styles['Heading2'],
            fontSize=12,
            textColor=colors.HexColor('#2c5aa0'),
            spaceAfter=8
        )
        
        # New style for table cells to allow text wrapping
        self.cell_style = ParagraphStyle(
            'CellStyle',
            parent=styles['Normal'],
            fontSize=7,
            leading=9,
            wordWrap='CJK'  # Helps with wrapping
        )
    
    def get_patient_list(self, num_patients: Optional[int] = None) -> List[str]:
        """
        Get list of unique patient IDs
        
        Args:
            num_patients: Number of patients to retrieve (None = all)
        
        Returns:
            List of unique patient IDs
        """
        patients = self.df['PatientID'].unique()
        if num_patients:
            patients = patients[:num_patients]
        return patients
    
    def create_pdf_for_patient(self, patient_id: str) -> bool:
        """
        Create PDF report for a single patient
        
        Args:
            patient_id: The patient ID to generate PDF for
        
        Returns:
            Boolean indicating success
        """
        try:
            patient_claims = self.df[self.df['PatientID'] == patient_id]
            
            if patient_claims.empty:
                print(f"  ✗ No claims found for patient {patient_id[:8]}")
                return False
            
            filename = os.path.join(self.output_dir, f"Patient_{patient_id[:8]}.pdf")
            # Changed to landscape to fit more columns
            doc = SimpleDocTemplate(filename, pagesize=landscape(letter))
            story = []
            
            # Add title
            story.append(Paragraph("Patient Healthcare Claim Report", self.title_style))
            story.append(Spacer(1, 0.2*inch))
            
            # Add patient information
            first_claim = patient_claims.iloc[0]
            patient_info = [
                ['Patient ID:', str(patient_id)[:16]],
                ['Gender/Age:', f"{first_claim['PatientGender']} - Age {first_claim['PatientAge']}"],
                ['Marital Status:', first_claim['PatientMaritalStatus']],
                ['Employment:', first_claim['PatientEmploymentStatus']],
                ['Income:', f"${first_claim['PatientIncome']:,.2f}"],
            ]
            
            patient_table = Table(patient_info, colWidths=[2*inch, 4*inch])
            patient_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#e8f0f8')),
                ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 9),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
                ('GRID', (0, 0), (-1, -1), 1, colors.grey)
            ]))
            
            story.append(patient_table)
            story.append(Spacer(1, 0.3*inch))
            
            # Add claims section header
            story.append(Paragraph(f"Claims Summary ({len(patient_claims)} claims)", self.heading_style))
            story.append(Spacer(1, 0.1*inch))
            
            # Build claims table with new fields
            # Headers including the new ProviderSpecialty field
            headers = ['Claim ID', 'Date', 'Diagnosis', 'Specialty', 'Reason', 'Medications', 'Tests', 'Amount', 'Status']
            claims_data = [headers]
            
            for idx, row in patient_claims.iterrows():
                # Use Paragraph for potentially long text fields to enable wrapping
                reason_para = Paragraph(str(row.get('Visit_Reason', '-')), self.cell_style)
                meds_para = Paragraph(str(row.get('Medications', '-')), self.cell_style)
                tests_para = Paragraph(str(row.get('Tests', '-')), self.cell_style)
                specialty_para = Paragraph(str(row.get('ProviderSpecialty', '-')), self.cell_style)
                
                claims_data.append([
                    str(row['ClaimID'])[:8] + '...',
                    str(row['ClaimDate']),
                    row['DiagnosisCode'],
                    specialty_para,  # Added Specialty here
                    reason_para,
                    meds_para,
                    tests_para,
                    f"${row['ClaimAmount']:,.2f}",
                    row['ClaimStatus']
                ])
            
            # Adjusted column widths to include Specialty (Total ~9 inches)
            col_widths = [
                0.8*inch,   # Claim ID
                0.75*inch,  # Date
                0.5*inch,   # Diagnosis
                0.9*inch,   # Specialty (New)
                1.1*inch,   # Reason
                1.65*inch,  # Medications
                1.65*inch,  # Tests
                0.85*inch,  # Amount
                0.7*inch    # Status
            ]
            
            claims_table = Table(claims_data, colWidths=col_widths)
            claims_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#2c5aa0')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),       # Default align left
                ('ALIGN', (0, 0), (-1, 0), 'CENTER'),      # Headers center
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 8),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),       # Vertical align top for wrapped text
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black),
                ('FONTSIZE', (0, 1), (-1, -1), 7),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f5f5f5')])
            ]))
            
            story.append(claims_table)
            story.append(Spacer(1, 0.2*inch))
            
            # Add summary statistics (Same as before)
            total_claims = len(patient_claims)
            total_amount = patient_claims['ClaimAmount'].sum()
            approved_claims = len(patient_claims[patient_claims['ClaimStatus'] == 'Approved'])
            pending_claims = len(patient_claims[patient_claims['ClaimStatus'] == 'Pending'])
            rejected_claims = len(patient_claims[patient_claims['ClaimStatus'] == 'Rejected'])
            
            summary_data = [
                ['Metric', 'Value'],
                ['Total Claims', str(total_claims)],
                ['Total Amount', f"${total_amount:,.2f}"],
                ['Approved', str(approved_claims)],
                ['Pending', str(pending_claims)],
                ['Rejected', str(rejected_claims)]
            ]
            
            summary_table = Table(summary_data, colWidths=[2.5*inch, 2.5*inch])
            summary_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1f4788')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('GRID', (0, 0), (-1, -1), 1, colors.grey),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#e8f0f8')])
            ]))
            
            story.append(Paragraph("Summary Statistics", self.heading_style))
            story.append(Spacer(1, 0.1*inch))
            story.append(summary_table)
            
            # Build and save PDF
            doc.build(story)
            return True
            
        except Exception as e:
            print(f"  ✗ Error creating PDF for {patient_id[:8]}: {str(e)}")
            return False
    
    def generate_batch(self, num_patients: int, start_index: int = 0):
        """
        Generate PDFs for multiple patients
        
        Args:
            num_patients: Number of patient PDFs to generate
            start_index: Index to start from (useful for batch processing)
        """
        patients = self.df['PatientID'].unique()[start_index:start_index + num_patients]
        
        print(f"\n📄 Generating {len(patients)} patient PDFs...")
        print(f"   Output directory: {self.output_dir}\n")
        
        success_count = 0
        
        for i, patient_id in enumerate(patients, 1):
            if self.create_pdf_for_patient(patient_id):
                success_count += 1
            
            if i % 10 == 0:
                print(f"  ✓ Progress: {i}/{len(patients)} PDFs created...")
        
        print(f"\n✅ Successfully created {success_count}/{len(patients)} PDFs")
        return success_count


def main():
    """Command line interface for PDF generation"""
    parser = argparse.ArgumentParser(description='Generate patient healthcare claim PDFs')
    parser.add_argument('csv_file', help='Path to cleaned CSV data file')
    parser.add_argument('--num-patients', type=int, default=50, 
                       help='Number of patients to generate PDFs for (default: 50)')
    parser.add_argument('--output-dir', default='patient_pdfs',
                       help='Output directory for PDFs (default: patient_pdfs)')
    parser.add_argument('--start-index', type=int, default=0,
                       help='Start index for batch processing (default: 0)')
    
    args = parser.parse_args()
    
    try:
        generator = PatientPDFGenerator(args.csv_file, args.output_dir)
        generator.generate_batch(args.num_patients, args.start_index)
    except Exception as e:
        print(f"✗ Error: {e}")
        return 1
    
    return 0


if __name__ == '__main__':
    exit(main())