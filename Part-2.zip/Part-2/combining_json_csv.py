import pandas as pd
import json
import glob

# Load the CSV
#df = pd.read_csv('/Users/jerrin.rajan/Desktop/BIA/Part-2/final.csv')
df = pd.read_csv('/Users/jerrin.rajan/Desktop/BIA/Part-2/cleaned.csv')
df['unstructured'] = None  # Initialize column

# Process all JSON files matching the pattern
json_files = glob.glob('/Users/jerrin.rajan/Desktop/BIA/Part-2/unstructured/Patient_*.json')

for json_file in json_files:
    # Extract ID (e.g., Patient_0a0eaceb.json -> 0a0eaceb)
    partial_id = json_file.split('_')[1].split('.')[0]
    
    # Load JSON data
    with open(json_file, 'r') as f:
        json_content = json.dumps(json.load(f))
    
    # Match and Update
    mask = df['PatientID'].str.startswith(partial_id, na=False)
    if mask.any():
        df.loc[mask, 'unstructured'] = json_content

# Save result
df.to_csv('merged_patient_data_all.csv', index=False)