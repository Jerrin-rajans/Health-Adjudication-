import os
import camelot
import pdfplumber
import pandas as pd
import re
import numpy as np
import json
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity


# =====================================================
# CONFIG
# =====================================================
PATIENT_PDF_DIR = "/Users/jerrin.rajan/Desktop/BIA/Part-2/patient_pdfs"
POLICY_PDF_PATH = "/Users/jerrin.rajan/Desktop/BIA/Part-2/Master_Medical_Policy_2025_Updated.pdf"
OUTPUT_DIR = "/Users/jerrin.rajan/Desktop/BIA/Part-2/unstructured"

os.makedirs(OUTPUT_DIR, exist_ok=True)


# =====================================================
# 1. Extract ALL tables from Claim PDF
# =====================================================
def extract_all_tables(pdf_path):
    tables = camelot.read_pdf(
        pdf_path,
        pages="all",
        flavor="lattice"  # change to "stream" if needed
    )

    if tables.n == 0:
        raise ValueError(" No tables found in claim PDF")

    dfs = []
    for table in tables:
        df = table.df
        df.columns = df.iloc[0]
        df = df[1:].reset_index(drop=True)
        dfs.append(df)

    return dfs


# =====================================================
# 2. Normalize column names
# =====================================================
def normalize_columns(df):
    df.columns = (
        df.columns.astype(str)
        .str.lower()
        .str.strip()
        .str.replace(r"[^a-z0-9 ]", "", regex=True)
    )
    return df


# =====================================================
# 3. Identify the CLAIMS table
# =====================================================
def is_claims_table(df):
    df = normalize_columns(df)
    joined = " ".join(df.columns)
    keywords = ["diagnosis", "medication", "test", "reason", "claim"]
    return any(k in joined for k in keywords)


def select_claims_table(dfs):
    for df in dfs:
        if is_claims_table(df):
            return df
    raise ValueError(
        " Claims table not found. Detected tables:\n" +
        "\n".join([str(df.columns.tolist()) for df in dfs])
    )


# =====================================================
# 4. Column resolver
# =====================================================
def find_column(df, keywords):
    for col in df.columns:
        for kw in keywords:
            if kw in col:
                return col
    return None


# =====================================================
# 5. Extract entities from table
# =====================================================
def extract_claim_entities_from_table(df):
    df = normalize_columns(df)

    diag_col = find_column(df, ["diagnosis", "dx"])
    reason_col = find_column(df, ["reason", "visit"])
    meds_col = find_column(df, ["medication", "drug"])
    tests_col = find_column(df, ["test", "procedure"])

    if not diag_col:
        raise ValueError(f" Diagnosis column not found. Columns: {df.columns.tolist()}")

    def split_clean(series):
        out = []
        for val in series.dropna():
            out.extend([x.strip().lower() for x in str(val).split(",")])
        return sorted(set(out))

    return {
        "Diagnosis": split_clean(df[diag_col]),
        "Medications": split_clean(df[meds_col]) if meds_col else [],
        "Tests": split_clean(df[tests_col]) if tests_col else [],
        "Visit Reason": split_clean(df[reason_col]) if reason_col else []
    }


# =====================================================
# 6. Extract & parse policy PDF
# =====================================================
def extract_policy_text(pdf_path):
    text = ""
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            if page.extract_text():
                text += page.extract_text() + "\n"
    return text.lower()


def parse_policy(policy_text):
    policy = {}
    current = None

    for line in policy_text.splitlines():
        if "specialty:" in line:
            current = line.split(":")[1].strip()
            policy[current] = {
                "max_claim_limit": None,
                "exclusions": []
            }

        if "max claim limit" in line and current:
            match = re.search(r"\$([\d,]+)", line)
            if match:
                policy[current]["max_claim_limit"] = match.group(1)

        if "specific exclusions" in line and current:
            exclusions = line.replace("specific exclusions", "")
            policy[current]["exclusions"] = [
                e.strip() for e in exclusions.split(",")
            ]

    return policy


# =====================================================
# 7. Clinical-context-based BERT reasoning
# =====================================================
bert_model = SentenceTransformer("all-MiniLM-L6-v2")


def clean_diagnoses(diagnoses):
    return [d for d in diagnoses if d and len(d.strip()) > 2]


def build_clinical_context(extracted):
    context = []
    context.extend(extracted.get("Visit Reason", []))
    context.extend(extracted.get("Tests", []))
    context.extend(extracted.get("Medications", []))
    context.extend(clean_diagnoses(extracted.get("Diagnosis", [])))
    return " ".join(context)


def build_specialty_profiles(policy):
    profiles = {}
    for specialty, rules in policy.items():
        text = specialty
        if rules.get("exclusions"):
            text += " " + " ".join(rules["exclusions"])
        profiles[specialty] = text
    return profiles


def map_to_policy_weighted(extracted, policy):
    context_text = build_clinical_context(extracted)
    if not context_text.strip():
        return []

    specialties = list(policy.keys())
    profiles = build_specialty_profiles(policy)

    context_emb = bert_model.encode([context_text])
    spec_embs = bert_model.encode([profiles[s] for s in specialties])

    scores = cosine_similarity(context_emb, spec_embs)[0]
    idx = np.argmax(scores)

    return [{
        "Clinical Context Used": context_text,
        "Matched Specialty": specialties[idx],
        "Policy Impact": policy[specialties[idx]],
        "Confidence": round(float(scores[idx]), 3)
    }]


# =====================================================
# 8. FULL ADJUDICATION PIPELINE
# =====================================================
def adjudication_pipeline(claim_pdf, policy_rules):
    all_tables = extract_all_tables(claim_pdf)
    claims_df = select_claims_table(all_tables)

    extracted_entities = extract_claim_entities_from_table(claims_df)

    policy_impact = map_to_policy_weighted(
        extracted_entities,
        policy_rules
    )

    return {
        "source_pdf": os.path.basename(claim_pdf),
        "Extracted Prescription Data": extracted_entities,
        "Insurance Policy Impact": policy_impact
    }


# =====================================================
# 9. BATCH RUN FOR ALL PATIENT PDFs
# =====================================================
if __name__ == "__main__":

    print(" Loading policy once...")
    policy_text = extract_policy_text(POLICY_PDF_PATH)
    policy_rules = parse_policy(policy_text)

    pdf_files = [
        f for f in os.listdir(PATIENT_PDF_DIR)
        if f.lower().endswith(".pdf")
    ]

    print(f" Found {len(pdf_files)} patient PDFs")

    for pdf_file in pdf_files:
        pdf_path = os.path.join(PATIENT_PDF_DIR, pdf_file)
        output_path = os.path.join(
            OUTPUT_DIR,
            pdf_file.replace(".pdf", ".json")
        )

        try:
            print(f"Processing {pdf_file}...")
            result = adjudication_pipeline(pdf_path, policy_rules)

            with open(output_path, "w") as f:
                json.dump(result, f, indent=2)

            print(f"Saved → {output_path}")

        except Exception as e:
            print(f"Failed for {pdf_file}: {e}")
